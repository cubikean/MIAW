  // start
  $(function() {
    _Fresco.initialize();
  });

  return Fresco;
});
