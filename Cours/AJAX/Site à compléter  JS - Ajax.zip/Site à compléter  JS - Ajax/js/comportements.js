    console.log("Exécution du programme comportement.js");

    document.querySelector("#recupObjet .bouton").addEventListener('click', recupererUnObjet);

    function recupererUnObjet() {
        // Tentative de récupération d'une donnée externe 
        const promesseRecupUnePersonne = axios.get('https://prodrigu.lpmiaw.univ-lr.fr/miaw/js_wdi/api_personnes/recupererUnePersAuHasard/');

        // Si la promesse est tenue, exécuter la fonction afficherPersonneAuHazard
        promesseRecupUnePersonne.then(afficherPersonneAuHasard);

        // Si la promesse n'est pas tenue, exécuter la fonction afficherErreurAjax
        promesseRecupUnePersonne.catch(afficherErreurAjax);
    }

    // Fonction de traitement de l'appel ajax à recupererUnePersAuHasard
    function afficherPersonneAuHasard(reponseAjax) {
        // le paramère reponseAjax contient à présent la réponse donnée par le serveur à l'appel Ajax.
        // Il faut donc placer ici les instructions permettant le traitement de cette donnée



    } //afficherPersonneAuHasard

    function afficherErreurAjax(erreur) {

    } //afficherErreurAjax